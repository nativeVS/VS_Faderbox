#include "Wsuggest-override.hpp"

W_SUGGEST_OVERRIDE_OFF
#include <gtest/gtest.h>
W_SUGGEST_OVERRIDE_ON