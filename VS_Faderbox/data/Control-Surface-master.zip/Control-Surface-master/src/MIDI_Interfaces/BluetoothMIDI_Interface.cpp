#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "BluetoothMIDI_Interface.hpp"
#endif