#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
// #include "MAX7219_Base.hpp" // TODO
#endif